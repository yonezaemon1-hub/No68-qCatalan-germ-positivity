#!/usr/bin/env python3
"""Small brute-force check of germ definition against Armstrong 2026 Table 1.
No C++ code, no DP recurrence, only literal enumeration of vectors and exact division.
"""
from itertools import product
from math import gcd

# Sparse expected coefficients transcribed from Table 1 of the source paper.
examples = {
 (3,1):{0:1}, (3,2):{2:1}, (3,4):{4:1},
 (4,1):{0:1}, (4,3):{2:1,3:1,4:1,6:1}, (4,9):{15:1},
 (5,1):{0:1}, (5,2):{2:1,4:1}, (5,3):{3:1,5:1,6:1,8:1},
 (5,4):{4:1,6:1,7:1,8:1,9:1,10:1,12:1},
}
for (a,c), expected in examples.items():
    cp = max((t for t in range(-1,c) if gcd(a,t)==1),default=-1)
    high = a*(a-1)*(a-1)//2
    coeff = [0]*(high+1)
    for xs in product(range(a),repeat=a-1):
        if cp < sum(xs) <= c:
            t = sum((i+1)*v for i,v in enumerate(xs))
            coeff[t] += 1
    # Division by 1+q+...+q^(a-1) via polynomial long division
    q = [0]*(high+1)
    for i in range(high+1):
        q[i] = coeff[i] - sum(q[i-j] for j in range(1,a) if i-j>=0)
    got={i:v for i,v in enumerate(q) if v}
    assert got==expected,(a,c,got,expected)
    print('BRUTE_FORCE_TABLE_PASS',a,c,len(expected))
print('ALL SMALL CASES PASS')
