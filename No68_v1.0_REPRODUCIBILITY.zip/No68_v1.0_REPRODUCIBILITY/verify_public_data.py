#!/usr/bin/env python3
"""Frozen-data/package consistency check; this alone does not rerun mathematics."""
from pathlib import Path
import hashlib, json, re, math
ROOT=Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()

def main():
    content=(ROOT/'SHA256SUMS.txt').read_text(encoding='utf8')
    for line in content.splitlines():
        if not line.strip() or line.startswith('#'): continue
        h,p=line.split('  ',1)
        assert (ROOT/p).is_file() and sha((ROOT/p).read_bytes())==h,(p,h)
    e=json.loads((ROOT/'EXPECTED_RESULTS_V03.json').read_text(encoding='utf8'))
    assert set(e)=={str(a) for a in range(21,33)}
    assert sum(int(v['germs']) for v in e.values())==4918
    assert all(v['negative']=='0' for v in e.values())
    for a in range(21,33):
        assert int(e[str(a)]['germs'])==(a-2)*sum(math.gcd(a,i)==1 for i in range(1,a+1))+1
    s=(ROOT/'CXX_RESULTS_V03.txt').read_text(encoding='utf8')
    rows=re.findall(r'method=(recurrence|inclusion) a=(\d+) germs=(\d+) negative=(\d+) positive=(\d+) largest=(\d+).*?digest128=([0-9a-f]{16}) digest256=([0-9a-f]{16})',s)
    assert len(rows)==24,len(rows)
    for method,a,g,n,p,m,d1,d2 in rows:
        v=e[a]
        assert (g,n,p,m,d1,d2)==tuple(v[k] for k in ('germs','negative','positive','largest','digest128','digest256'))
    print('NO68_V10_PUBLIC_DATA_AUDIT_PASS -- checksum and frozen record consistency only')

if __name__=='__main__':main()
