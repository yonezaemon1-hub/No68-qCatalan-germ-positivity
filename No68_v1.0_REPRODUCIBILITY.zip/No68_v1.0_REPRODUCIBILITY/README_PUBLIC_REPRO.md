# No.68 v1.0 — Reproducibility kit

**Author:** Ryutaro Yonezu — Independent Researcher  
**Status:** v1.0, unreviewed finite-computation preprint; AI-assisted audit; no independent human peer review.  
**License:** All rights reserved (unchanged; no permission to redistribute or modify without approval).  
**Scope:** finite verification of Armstrong q-Catalan germ positivity for 3 <= a <= 32; not an unrestricted proof.

This directory contains only source code, frozen expectations, checksum records and documentation. It excludes private Windows logs, private audit packages, local terminal transcripts, credentials, email addresses, and absolute user-specific paths.

## Requirements

- Python 3.10 or newer, standard library only.
- Optional: C++17 compiler and Boost.Multiprecision headers (`boost/multiprecision/cpp_int.hpp`) for frozen two-method C++ rechecks.
- For full Windows evidence, Windows PowerShell 5.1 can invoke `WINDOWS_REPRO_V1_0.ps1` from the extracted folder.

## Quick run

```sh
python -B verify_public_data.py
python -B run_reproduce.py --a 21
```

`verify_public_data.py` (v1.0 PASS marker) checks SHA-256 and previously frozen records; it does not recompute mathematics. `run_reproduce.py` reruns the Python recurrence and division and checks the stored summary when `a=21..32`. For small-a checks use e.g. `python -B run_reproduce.py --a 8`.

## Full exact reproduction (potentially resource-intensive)

```sh
python -B run_reproduce.py --full
```

Expected marker: `NO68_V10_PYTHON_FULL_PASS a=21..32`. For older range 3..20 use `python -B run_reproduce.py --a 3` through `--a 20`.

C++ (example commands on Linux with g++ and Boost installed):

```sh
g++ -O3 -std=c++17 verify_256.cpp -o verify_256
./verify_256 recurrence 21
./verify_256 inclusion 21
```

To check other values, replace `21`. The C++ program accepts 3..32. Compare the printed full summary to `CXX_RESULTS_V03.txt` for 21..32. Full coefficient-stream identity hashes for 28..32 are historical evidence from a frozen earlier audit and are not automatically recalculated by the fast path. If supplying optional `certificate_file`, the executable writes potentially huge binary streams; avoid on constrained disks.

Definition-level brute-force checks (`verify_small_cases.py`) compare 10 source-paper examples for a=3..5. The additional `verify_bruteforce_to8.py --a 6` (also 7,8) directly enumerates all vectors without numerator DP and uses ordinary polynomial long division. a=8 may take material time and RAM.

## Checksum vocabulary

The names `digest128` and `digest256` are historical and refer to input coefficient **width**, not the output size. Both are 64-bit **word-wise FNV-style digests**, computed by XORing successive 64-bit words and multiplying by FNV prime modulo 2^64. They are **not** the standard byte-wise FNV-1a digest and are **not** cryptographic hashes. `digest128` processes two words; `digest256` processes four. The separate `COEFFICIENT_IDENTITY.txt` contains SHA-256 of selected full byte streams; raw streams are not retained.

The Python verifier and C++ `recurrence` share the same bounded numerator recurrence. C++ `inclusion` is a different numerator algorithm. All use the same algebraic quotient identity, with reconstruction and tail tests in C++. Direct enumeration for a <= 8 provides a further independent check of the numerator counts. The conclusion remains finite and machine-dependent.

## Publication and audit limits

This is the code/data kit accompanying the v1.0 preprint. AI-assisted audits are reported separately; no independent human peer review occurred. Novelty is INCONCLUSIVE; references PARTIAL. Windows logs remain private. Private research archives are excluded from this public distribution. No contact with the original author is implied.

## Windows proof-of-execution provenance

A second author-operated Windows full run dated 14 November 2026 was reported using Windows 10 (10.0.19045), PowerShell 5.1.19041.7844 and Python 3.12.10. Its pasted terminal transcript was reported to show 14 zero exit statuses, the expected SHA-256, and full-run markers for all a=21..32. The private source log itself and the original log bytes are **not included or authenticated** in this kit; the author reported a SHA-256 value for the privately retained file, but the file itself has not been checked against that value. The terminal transcript includes personal Windows paths and must not be publicly distributed. The present v1.0 script prints interpreter-neutral `COMMAND: python ...` lines to avoid new path leakage. An independent reviewer should rerun the tools rather than treating this prose as a cryptographic execution attestation.

**Log-sharing safety:** On a failed run, child-process standard error and Python tracebacks can print absolute local paths even though successful `COMMAND:` lines are path-free. Keep raw Windows logs private and inspect/redact any failed-run log before sharing or publishing it. A redacted copy is not a substitute for the privately retained original.

Publication of this kit does not grant a software reuse license; obtain the author's permission before redistribution or modification.
