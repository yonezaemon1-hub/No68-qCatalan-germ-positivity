// No68 extension: two independent exact methods with signed 256-bit coefficients.
// Usage: verify_256 recurrence|inclusion a [optional_certificate_file]
// No original v0.2 file is modified.
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <map>
#include <iostream>
#include <numeric>
#include <string>
#include <vector>
#include <boost/multiprecision/cpp_int.hpp>
using boost::multiprecision::int256_t;
using boost::multiprecision::uint256_t;
using std::vector;
using Z = int256_t;

constexpr uint64_t FNV_PRIME=1099511628211ULL;
uint64_t digest_word(uint64_t digest, uint64_t word){return (digest^word)*FNV_PRIME;}
int main(int argc,char**argv){
 if (argc<3){std::cerr<<"usage: verify_256 recurrence|inclusion a [certificate_file]\n";return 2;}
 const std::string method=argv[1];
 const int a=std::stoi(argv[2]);
 if (method!="recurrence" && method!="inclusion"){std::cerr<<"unknown method\n";return 2;}
 if (a<3 || a>32){std::cerr<<"validated parameter range 3..32\n";return 2;}
 const int S=(a-1)*(a-1), W=a*S/2+1;
 const size_t N=(size_t)(S+1)*W;
 vector<Z> D(N), newD;
 D[0]=1;
 if (method=="recurrence"){
   newD.resize(N);
   for(int i=1;i<a;i++){
     std::fill(newD.begin(),newD.end(),Z(0));
     const int sHi=i*(a-1),wHi=i*(i+1)*(a-1)/2;
     for(int s=0;s<=sHi;s++){
       const size_t base=(size_t)s*W;
       for(int w=0;w<=wHi;w++){
         Z val = D[base+w];
         if(s && w>=i)val += newD[base-W+w-i];
         if(s>=a && w>=i*a)val -= D[base-(size_t)a*W+w-a*i];
         if(val<0){std::cerr<<"negative recurrence\n";return 3;}
         newD[base+w]=val;
       }
     }
     D.swap(newD);
   }
 }else{
   for(int i=1;i<a;i++)
     for(int s=1;s<=S;s++)
       for(int w=i;w<W;w++)
         D[(size_t)s*W+w]+=D[(size_t)(s-1)*W+w-i];
   for(int i=1;i<a;i++)
     for(int s=S;s>=a;s--)
       for(int w=W-1;w>=a*i;w--){
         Z& v=D[(size_t)s*W+w];
         v-=D[(size_t)(s-a)*W+w-a*i];
         if(v<0){std::cerr<<"negative inclusion\n";return 4;}
       }
 }
 std::ofstream cert;
 if(argc>=4){cert.open(argv[3],std::ios::binary);if(!cert){std::cerr<<"cannot open cert\n";return 5;}}
 // Fixed-width unsigned-256 little-endian 32 bytes, in ascending c then w.
 vector<Z> P(W),Q(W);
 int last=-1,germs=0;
 uint64_t digest64=14695981039346656037ULL;
 uint64_t digest256=digest64;
 uint64_t positive=0,negative=0;
 std::map<int,int> predecessor, lookup;
 vector<vector<Z>> all_germs;
 Z sum_at_q1=0;
 Z largest=0; int max_degree=0;
 for(int c=1;c<=S;c++){
   if(std::gcd(a,c)!=1)continue;
   predecessor[c]=last;
   lookup[c]=(int)all_germs.size();
   std::fill(P.begin(),P.end(),Z(0));
   std::fill(Q.begin(),Q.end(),Z(0));
   for(int s=last+1;s<=c;s++){
     const size_t base=(size_t)s*W;
     for(int w=0;w<W;w++)P[w]+=D[base+w];
   }
   for(int w=0;w<W;w++){
     Z val=P[w]-(w?P[w-1]:Z(0))+(w>=a?Q[w-a]:Z(0));
     Q[w]=val;
     if(val<0)++negative;
     if(val>0){++positive; if(val>largest)largest=val;max_degree=std::max(max_degree,w);}
     if(val>=0){
       const uint256_t uv=static_cast<uint256_t>(val);
       for(int j=0;j<4;j++){
         const uint64_t word=static_cast<uint64_t>((uv>>(64*j)) & 0xffffffffffffffffULL);
         digest256=digest_word(digest256,word);
         if(j<2)digest64=digest_word(digest64,word);
         if(cert)for(int k=0;k<8;k++)cert.put(static_cast<char>(word>>(k*8)));
       }
     }
   }
   for(int w=W-a+1;w<W;w++)if(Q[w]!=0){std::cerr<<"division tail fail: c="<<c<<" w="<<w<<"\n";return 6;}
   // Independent exact reconstruction of numerator from quotient
   for(int w=0;w<W;w++){
     Z recon=Q[w]-(w>=a?Q[w-a]:Z(0))+(w?P[w-1]:Z(0));
     if(recon!=P[w]){std::cerr<<"quotient reconstruction fail\n";return 7;}
   }
   if(negative){std::cerr<<"negative germ c="<<c<<"\n";return 8;}
   Z numerator_at_one=0,quotient_at_one=0;
   for(int w=0;w<W;w++){numerator_at_one+=P[w];quotient_at_one+=Q[w];}
   if(numerator_at_one!=a*quotient_at_one){std::cerr<<"q1 evaluation fail c="<<c<<"\n";return 9;}
   sum_at_q1+=quotient_at_one;
   all_germs.push_back(Q);
   ++germs;last=c;
 }
 Z expected=1;
 for(int j=0;j<a-2;j++)expected*=a;
 if(sum_at_q1!=expected){std::cerr<<"global q1 fail\n";return 10;}
 const int K=a*S/2-(a-1);
 for(const auto& ent:predecessor){
   const int c=ent.first,d=S-ent.second-1;
   if(!lookup.count(d)){std::cerr<<"missing reversal partner c="<<c<<"\n";return 11;}
   const auto& G=all_germs[lookup[c]];
   const auto& R=all_germs[lookup[d]];
   for(int w=0;w<=K;w++)if(G[w]!=R[K-w]){
     std::cerr<<"reciprocal pairing fails c="<<c<<",d="<<d<<",w="<<w<<"\n";return 12;
   }
 }
 std::cout<<"method="<<method<<" a="<<a<<" germs="<<germs
          <<" negative="<<negative<<" positive="<<positive
          <<" largest="<<largest<<" max_degree="<<max_degree
          <<" q1_sum="<<sum_at_q1<<" reciprocal=PASS"
          <<" digest128="<<std::hex<<std::setfill('0')<<std::setw(16)<<digest64
          <<" digest256="<<std::setw(16)<<digest256<<std::dec<<"\n";
}
