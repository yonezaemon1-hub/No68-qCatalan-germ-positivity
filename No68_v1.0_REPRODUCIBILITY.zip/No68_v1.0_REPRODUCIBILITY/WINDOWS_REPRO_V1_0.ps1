# No68 v1.0 research reproducibility kit. Windows PowerShell 5.1 / Python 3.10+
# Execute from the extracted public reproducibility kit directory.
$ErrorActionPreference = 'Stop'
$work = Split-Path -Parent $MyInvocation.MyCommand.Path
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$log = Join-Path $work ("No68_V10_WINDOWS_LOG_" + $stamp + ".txt")
Push-Location -LiteralPath $work
try {
    $exitCode = 0
    $lines = @()
    $lines += '=== NO68 v1.0 REPRO START ==='
    $lines += ('TIMESTAMP_LOCAL=' + (Get-Date -Format 'yyyy-MM-ddTHH:mm:sszzz'))
    $lines += ('POWERSHELL_VERSION=' + $PSVersionTable.PSVersion.ToString())
    $lines += ('OS=' + [Environment]::OSVersion.VersionString)
    $lines += ('PYTHON_VERSION=' + ((python --version 2>&1) | Out-String).Trim())
    if ($LASTEXITCODE -ne 0) { throw 'Python --version failed' }
    $lines += ('EXPECTED_SHA256=' + (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $work 'EXPECTED_RESULTS_V03.json')).Hash.ToLowerInvariant())
    $lines | Tee-Object -FilePath $log
    & python -B run_reproduce.py --full 2>&1 | Tee-Object -FilePath $log -Append
    $exitCode = $LASTEXITCODE
    ('PYTHON_EXIT_CODE=' + $exitCode) | Tee-Object -FilePath $log -Append
    if ($exitCode -ne 0) { throw ('Reproduction failed with exit=' + $exitCode) }
    ('END_TIMESTAMP_LOCAL=' + (Get-Date -Format 'yyyy-MM-ddTHH:mm:sszzz')) | Tee-Object -FilePath $log -Append
    'NO68_V10_WINDOWS_FULL_RUN_PASS' | Tee-Object -FilePath $log -Append
    Write-Host ('Evidence log: ' + $log)
} finally { Pop-Location }
