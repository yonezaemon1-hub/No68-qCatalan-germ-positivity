#!/usr/bin/env python3
"""Standalone stdlib-only exact recheck for No.68. Python 3.10+ / PowerShell 5.1.
No third-party packages or C++ compiler. Full a=21 is default; a=27 consumes RAM.
"""
import argparse
import math

MASK64 = (1 << 64) - 1
MASK128 = (1 << 128) - 1
FNV_PRIME = 1099511628211


def verify(a: int) -> None:
    if not 3 <= a <= 32:
        raise SystemExit('Supported interval 3..32 (larger a needs resource/overflow reassessment)')
    S = (a - 1) ** 2
    W = a * S // 2 + 1
    dp = [[0] * W for _ in range(S + 1)]
    dp[0][0] = 1
    for i in range(1, a):
        new = [[0] * W for _ in range(S + 1)]
        smax = i * (a - 1)
        wmax = i * (i + 1) * (a - 1) // 2
        for s in range(smax + 1):
            row = new[s]
            old = dp[s]
            left = new[s - 1] if s else None
            sub = dp[s - a] if s >= a else None
            for w in range(wmax + 1):
                v = old[w]
                if left is not None and w >= i:
                    v += left[w - i]
                if sub is not None and w >= a * i:
                    v -= sub[w - a * i]
                if v < 0:
                    raise AssertionError(('negative DP', a, i, s, w))
                row[w] = v
        dp = new
    # Each c's predecessor is the previous coprime c, with predecessor=-1 at c=1.
    last = -1
    digest = 14695981039346656037
    digest256 = digest
    germs = negative = positive = 0
    maxval = 0
    for c in range(1, S + 1):
        if math.gcd(a, c) != 1:
            continue
        num = [0] * W
        for s in range(last + 1, c + 1):
            row = dp[s]
            for w in range(W):
                num[w] += row[w]
        Q = [0] * W
        for w in range(W):
            v = num[w] - (num[w - 1] if w else 0) + (Q[w - a] if w >= a else 0)
            Q[w] = v
            negative += (v < 0)
            positive += (v > 0)
            if v > maxval:
                maxval = v
            unsigned = v & MASK128
            digest ^= unsigned & MASK64
            digest = digest * FNV_PRIME & MASK64
            digest ^= (unsigned >> 64) & MASK64
            digest = digest * FNV_PRIME & MASK64
            for j in range(4):
                digest256 ^= (v >> (64*j)) & MASK64
                digest256 = digest256 * FNV_PRIME & MASK64
        if any(Q[W - a + 1:]):
            raise AssertionError(('nonzero quotient tail', a, c))
        if any(v < 0 for v in Q):
            raise AssertionError(('negative germ', a, c))
        germs += 1
        last = c
    print(f'PYTHON_VERIFY_PASS a={a} germs={germs} negative={negative} '
          f'positive={positive} largest={maxval} digest128={digest:016x} digest256={digest256:016x}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('a', type=int, nargs='?', default=21)
    args = parser.parse_args()
    verify(args.a)
