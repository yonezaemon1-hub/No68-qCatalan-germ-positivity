#!/usr/bin/env python3
"""Definition-level enumeration, a=3..8. Slow for a=8; no numerator DP.

Directly counts (sum x_i, tilted height) for all vectors and divides by [a]_q
using ordinary low-to-high polynomial long division (not (1-q^a)/(1-q) recurrence).
"""
from itertools import product
from math import gcd
from collections import defaultdict
import argparse

MASK=(1<<64)-1
PRIME=1099511628211

def compute(a):
    S=(a-1)**2
    W=a*S//2+1
    vectors_by_s=[defaultdict(int) for _ in range(S+1)]
    for x in product(range(a),repeat=a-1):
        s=sum(x)
        w=sum(i*v for i,v in enumerate(x,1))
        vectors_by_s[s][w]+=1
    dp128=dp256=14695981039346656037
    germs=pos=neg=largest=0
    prev=-1
    for c in range(1,S+1):
        if gcd(a,c)!=1:continue
        p=[0]*W
        for s in range(prev+1,c+1):
            for w,v in vectors_by_s[s].items():p[w]+=v
        # Ordinary long division by 1+q+...+q^(a-1), avoiding the numerator DP
        q=[0]*W
        rolling=0
        for w in range(W):
            if w>=a:rolling-=q[w-a]
            q[w]=p[w]-rolling
            rolling+=q[w]
        if any(q[-a+1:]):raise AssertionError('nonzero quotient tail')
        for v in q:
            if v<0:neg+=1
            if v>0:
                pos+=1
                largest=max(largest,v)
            for j in range(2):
                dp128=((dp128^((v>>(64*j))&MASK))*PRIME)&MASK
            for j in range(4):
                dp256=((dp256^((v>>(64*j))&MASK))*PRIME)&MASK
        germs+=1
        prev=c
    return dict(germs=germs,negative=neg,positive=pos,largest=largest,
                digest128=f'{dp128:016x}',digest256=f'{dp256:016x}')

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--a',type=int,default=6)
    args=ap.parse_args()
    if not 3<=args.a<=8:raise SystemExit('This brute-force checker is limited to a=3..8')
    res=compute(args.a)
    print('BRUTEFORCE_VERIFY_PASS a=',args.a,*[f'{k}={v}' for k,v in res.items()])
