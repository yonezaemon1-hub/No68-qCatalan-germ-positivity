#!/usr/bin/env python3
"""Reproduce No.68: stdlib-only Python; redact interpreter paths in command display."""
import argparse, datetime, json, os, platform, pathlib, re, subprocess, sys, hashlib
ROOT=pathlib.Path(__file__).resolve().parent

def run(argv):
    print('COMMAND:', ' '.join(['python'] + argv[1:]),flush=True)
    p=subprocess.run(argv,cwd=ROOT,text=True,encoding='utf-8',capture_output=True)
    print(p.stdout,end='',flush=True)
    if p.stderr:print(p.stderr,file=sys.stderr,end='',flush=True)
    print('EXIT_CODE:',p.returncode,flush=True)
    if p.returncode:raise SystemExit(p.returncode)
    return p.stdout

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--full',action='store_true',help='Run all a=21..32; computationally substantial')
    ap.add_argument('--a',type=int,default=21,help='Single a=3..32; ignored with --full')
    args=ap.parse_args()
    expected=json.loads((ROOT/'EXPECTED_RESULTS_V03.json').read_text())
    print('TIME_UTC:',datetime.datetime.now(datetime.timezone.utc).isoformat())
    print('PLATFORM:',platform.platform())
    print('PYTHON:',sys.version.replace('\n',' '))
    print('PUBLIC_DATA_SHA256:',hashlib.sha256((ROOT/'EXPECTED_RESULTS_V03.json').read_bytes()).hexdigest())
    run([sys.executable,'-B','verify_public_data.py'])
    run([sys.executable,'-B','verify_small_cases.py'])
    a_list=list(range(21,33)) if args.full else [args.a]
    for a in a_list:
        s=run([sys.executable,'-B','verify_python256.py',str(a)])
        if 21<=a<=32:
            line=[v for v in s.splitlines() if v.startswith('PYTHON_VERIFY_PASS a=')]
            if len(line)!=1:raise AssertionError(f'no unique result for a={a}')
            got=dict(re.findall(r'([a-z0-9_]+)=([^ ]+)',line[0]))
            bad=[k for k,v in expected[str(a)].items() if got.get(k)!=v]
            if bad:raise AssertionError(f'frozen mismatch a={a}, fields={bad}')
        else:
            if f'negative=0' not in s:raise AssertionError('unexpected sign result')
    if args.full:
        print('NO68_V10_PYTHON_FULL_PASS a=21..32')
    else:
        print(f'NO68_V10_PYTHON_SINGLE_PASS a={args.a} (not full-range verification)')

if __name__=='__main__':main()
